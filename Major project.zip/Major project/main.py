from flask import Flask, render_template, request, send_from_directory, redirect, flash
from tensorflow.keras.models import load_model
from tensorflow.keras.preprocessing.image import load_img, img_to_array
import numpy as np
import sqlite3
from datetime import datetime
import os

# Initialize Flask app
app = Flask(__name__)
app.secret_key = 'secret123'  # Needed for flash messages

# Load the trained VGG16 model
model_path = r'F:\Major project\Models\model.h5'
model = load_model(model_path)

# Class labels (do not change)
class_labels = ['glioma', 'meningioma', 'notumor', 'pituitary']

# Define the uploads folder
UPLOAD_FOLDER = './uploads'
if not os.path.exists(UPLOAD_FOLDER):
    os.makedirs(UPLOAD_FOLDER)

app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

# ✅ Helper function to predict tumor type (unchanged)
def predict_tumor(image_path):
    IMAGE_SIZE = 128
    img = load_img(image_path, target_size=(IMAGE_SIZE, IMAGE_SIZE))
    img_array = img_to_array(img) / 255.0
    img_array = np.expand_dims(img_array, axis=0)

    predictions = model.predict(img_array)
    predicted_class_index = np.argmax(predictions, axis=1)[0]
    confidence_score = np.max(predictions, axis=1)[0]

    if class_labels[predicted_class_index] == 'notumor':
        return "No Tumor Detected", confidence_score
    else:
        return f"Tumor Detected: {class_labels[predicted_class_index]}", confidence_score

# ✅ Function to save consultation data in SQLite
def save_consultation(name, email, phone, date, time, concerns):
    conn = sqlite3.connect('consultation.db')
    cursor = conn.cursor()
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS consultations (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            full_name TEXT,
            email TEXT,
            phone TEXT,
            preferred_date TEXT,
            preferred_time TEXT,
            concerns TEXT,
            submitted_at TEXT
        )
    ''')
    cursor.execute('''
        INSERT INTO consultations
        (full_name, email, phone, preferred_date, preferred_time, concerns, submitted_at)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    ''', (name, email, phone, date, time, concerns, datetime.now().strftime("%Y-%m-%d %H:%M:%S")))
    conn.commit()
    conn.close()

# ✅ Unified route to handle both prediction and consultation form
@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        # If file uploaded for prediction
        if 'file' in request.files and request.files['file'].filename != '':
            file = request.files['file']
            file_location = os.path.join(app.config['UPLOAD_FOLDER'], file.filename)
            file.save(file_location)

            result, confidence = predict_tumor(file_location)

            return render_template('index.html',
                                   result=result,
                                   confidence=f"{confidence*100:.2f}%",
                                   file_path=f'/uploads/{file.filename}')

        # If form submitted for consultation
        if 'name' in request.form:
            name = request.form['name']
            email = request.form['email']
            phone = request.form['phone']
            date = request.form['date']
            time = request.form['time']
            concerns = request.form['concerns']

            save_consultation(name, email, phone, date, time, concerns)
            flash("Consultation request submitted successfully!", "success")
            return redirect('/')

    return render_template('index.html', result=None)

# ✅ Serve uploaded images
@app.route('/uploads/<filename>')
def get_uploaded_file(filename):
    return send_from_directory(app.config['UPLOAD_FOLDER'], filename)

@app.route('/submissions')
def view_submissions():
    conn = sqlite3.connect('consultation.db')
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM consultations ORDER BY submitted_at DESC')
    rows = cursor.fetchall()
    conn.close()

    return render_template('submissions.html', submissions=rows)


# ✅ Run Flask app
if __name__ == '__main__':
    app.run(debug=True)
